from distutils.core import setup
setup(name='piratestrike',
      version='0.1',
      py_modules=['piratestrike'],
      )
